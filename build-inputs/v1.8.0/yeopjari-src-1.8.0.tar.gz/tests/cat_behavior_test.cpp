#include "../src/cat_behavior.hpp"

#include <array>
#include <functional>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
using cat::behavior::Action;
using cat::behavior::Brain;
using cat::behavior::Context;
int checks = 0;
#define CHECK(condition) do { ++checks; if (!(condition)) throw std::runtime_error( \
    std::string(__FILE__) + ":" + std::to_string(__LINE__) + " failed: " #condition); } while (false)

constexpr std::int64_t Birthday = 1793416455;
constexpr std::uint64_t Minute = 60 * 1000, Hour = 60 * Minute;
bool Stationary(Action a) {
    return a == Action::Idle || a == Action::Sleep || a == Action::Groom || a == Action::Stretch || a == Action::Watch || a == Action::EarFlick || a == Action::TailRaise;
}
bool Surprise(Action a) {
    return a == Action::Zoomies || a == Action::TailChase || a == Action::Jump;
}
bool Gesture(Action a) {
    return a == Action::EarFlick || a == Action::TailRaise;
}

void PersonalityAndRepeatability() {
    Brain one(Birthday, 1), two(Birthday, 500), other(Birthday + 1, 1);
    const auto a = one.GetPersonality(), b = two.GetPersonality(), c = other.GetPersonality();
    CHECK(a.curiosity == b.curiosity && a.energy == b.energy && a.sociability == b.sociability && a.mischief == b.mischief);
    CHECK(a.curiosity != c.curiosity || a.energy != c.energy || a.sociability != c.sociability || a.mischief != c.mischief);
    for (double score : {a.curiosity, a.energy, a.sociability, a.mischief}) CHECK(score >= 0.18 && score < 0.82);
    Brain repeatA(Birthday, 77), repeatB(Birthday, 77);
    Context ctx;
    for (int i = 0; i < 500; ++i) {
        ctx.cursorNear = i % 3 == 0;
        const auto x = repeatA.Next(ctx), y = repeatB.Next(ctx);
        CHECK(x.action == y.action && x.durationMs == y.durationMs && x.speed == y.speed);
        ctx.ticks += x.durationMs;
    }
}

void CalmRhythmAndSequences() {
    std::uint64_t stationaryTime = 0, intenseTime = 0, allTime = 0;
    std::array<unsigned, static_cast<unsigned>(Action::TailRaise) + 1> seen{};
    Brain brain(Birthday, 15);
    Context ctx; ctx.cursorNear = true;
    Action previous = Action::Idle;
    while (ctx.ticks < 72 * Hour) {
        ctx.localHour = static_cast<int>((ctx.ticks / Hour + 8) % 24);
        const auto plan = brain.Next(ctx);
        CHECK(plan.durationMs >= 1000 && plan.durationMs <= 120000);
        CHECK(plan.speed >= 0.0 && plan.speed <= 250.0);
        if (previous == Action::Sleep) CHECK(plan.action == Action::Stretch);
        if (previous == Action::Stalk) CHECK(plan.action == Action::Pounce);
        if (previous == Action::Pounce) CHECK(plan.action == Action::Watch);
        if (previous == Action::Punch) CHECK(plan.action == Action::Idle);
        if (previous == Action::Jump) CHECK(plan.action == Action::Watch || plan.action == Action::Idle || plan.action == Action::Groom);
        if (Gesture(previous)) CHECK(plan.action == Action::Idle || plan.action == Action::Watch);
        if (Stationary(plan.action)) stationaryTime += plan.durationMs;
        if (plan.action == Action::Punch || Surprise(plan.action) || plan.action == Action::Pounce) intenseTime += plan.durationMs;
        ++seen[static_cast<unsigned>(plan.action)];
        allTime += plan.durationMs; ctx.ticks += plan.durationMs; previous = plan.action;
    }
    CHECK(static_cast<double>(stationaryTime) / allTime > 0.65);
    CHECK(static_cast<double>(intenseTime) / allTime < 0.04);
    for (auto count : seen) CHECK(count > 0);
}

void GentleGesturesAndPause() {
    Brain brain(Birthday, 31);
    Context ctx; ctx.roamingPaused = true; ctx.cursorNear = true;
    std::uint64_t lastGesture = 0;
    unsigned ears = 0, tails = 0;
    Action previous = Action::Idle;
    while (ctx.ticks < 24 * Hour) {
        const auto plan = brain.Next(ctx);
        CHECK(Stationary(plan.action));
        CHECK(plan.speed == 0.0);
        if (Gesture(previous)) CHECK(plan.action == Action::Idle || plan.action == Action::Watch);
        if (Gesture(plan.action)) {
            CHECK(ctx.ticks - lastGesture >= Brain::GestureMinGapMs);
            lastGesture = ctx.ticks;
            if (plan.action == Action::EarFlick) { ++ears; CHECK(plan.durationMs == 2200); }
            if (plan.action == Action::TailRaise) { ++tails; CHECK(plan.durationMs == 3400); }
        }
        previous = plan.action; ctx.ticks += plan.durationMs;
    }
    CHECK(ears > 10 && tails > 10);

    // Gentle gestures remain available during a punch cooldown. They do not
    // borrow or reset the long surprise cooldown used by active pranks.
    unsigned gentle = 0;
    for (unsigned seed = 1; seed <= 20; ++seed) {
        Brain afterPunch(Birthday, seed);
        ctx = {}; ctx.cursorNear = true;
        afterPunch.MarkPunch(ctx.ticks);
        while (ctx.ticks < Brain::PunchMinGapMs) {
            const auto plan = afterPunch.Next(ctx);
            CHECK(plan.action != Action::Punch);
            if (Gesture(plan.action)) ++gentle;
            ctx.ticks += plan.durationMs;
        }
    }
    CHECK(gentle > 0);

    // Rebase the independent gesture timer when the monotonic source changes.
    Brain rollback(Birthday, 3);
    ctx = {}; ctx.ticks = 100 * Hour; ctx.roamingPaused = true;
    rollback.Next(ctx);
    ctx.ticks = 100;
    const auto start = ctx.ticks;
    while (ctx.ticks < start + Brain::GestureMinGapMs) {
        const auto plan = rollback.Next(ctx);
        CHECK(!Gesture(plan.action));
        ctx.ticks += plan.durationMs;
    }
}

void CooldownsAndHighUptime() {
    const std::uint64_t start = 90 * 24 * Hour;
    Context ctx; ctx.ticks = start; ctx.cursorNear = true;
    Brain brain(Birthday, 85);
    std::uint64_t lastPunch = start, lastSurprise = 0, lastStalk = 0;
    int punches = 0;
    while (ctx.ticks < start + 48 * Hour) {
        const auto plan = brain.Next(ctx);
        if (plan.action == Action::Punch) {
            CHECK(ctx.ticks - lastPunch >= Brain::PunchMinGapMs);
            lastPunch = ctx.ticks; ++punches;
        }
        if (Surprise(plan.action)) {
            if (lastSurprise) CHECK(ctx.ticks - lastSurprise >= Brain::SurpriseMinGapMs);
            lastSurprise = ctx.ticks;
        }
        if (plan.action == Action::Stalk) {
            if (lastStalk) CHECK(ctx.ticks - lastStalk >= Brain::StalkMinGapMs);
            lastStalk = ctx.ticks;
        }
        ctx.ticks += plan.durationMs;
    }
    CHECK(punches >= 20 && punches <= 240);

    brain.MarkPunch(ctx.ticks);
    const auto forcedAt = ctx.ticks;
    CHECK(brain.Next(ctx).action == Action::Idle);
    while (ctx.ticks < forcedAt + Brain::PunchMinGapMs) {
        const auto plan = brain.Next(ctx);
        CHECK(plan.action != Action::Punch);
        ctx.ticks += plan.durationMs;
    }
}

void IndependentJumpAndRecovery() {
    Brain brain(Birthday, 17);
    Context ctx; // The new jump must not need a nearby cursor or a stalk sequence.
    std::uint64_t lastSurprise = 0;
    unsigned jumps = 0, walks = 0;
    bool expectRecovery = false;
    while (ctx.ticks < 72 * Hour) {
        const auto plan = brain.Next(ctx);
        if (expectRecovery) {
            CHECK(plan.action == Action::Watch || plan.action == Action::Idle || plan.action == Action::Groom);
            expectRecovery = false;
        }
        if (plan.action == Action::Walk) ++walks;
        if (Surprise(plan.action)) {
            if (lastSurprise) CHECK(ctx.ticks - lastSurprise >= Brain::SurpriseMinGapMs);
            lastSurprise = ctx.ticks;
        }
        if (plan.action == Action::Jump) {
            ++jumps;
            CHECK(plan.durationMs == 1450);
            CHECK(plan.speed == 0.0);
            expectRecovery = true;
        }
        CHECK(plan.action != Action::Stalk && plan.action != Action::Pounce);
        ctx.ticks += plan.durationMs;
    }
    CHECK(jumps > 10 && walks > jumps * 3);

    // Pausing during a jump still selects a calm follow-up and suppresses
    // further vertical jumps even when their normal cooldown has expired.
    Brain pausing(Birthday, 17);
    ctx = {};
    bool foundJump = false;
    for (int i = 0; i < 1500; ++i) {
        const auto plan = pausing.Next(ctx);
        ctx.ticks += plan.durationMs;
        if (plan.action == Action::Jump) { foundJump = true; break; }
    }
    CHECK(foundJump);
    ctx.roamingPaused = true;
    for (int i = 0; i < 500; ++i) {
        const auto plan = pausing.Next(ctx);
        CHECK(Stationary(plan.action));
        CHECK(plan.action != Action::Jump);
        ctx.ticks += plan.durationMs;
    }
}

void CareAndPause() {
    Brain brain(Birthday, 20);
    Context ctx; ctx.ticks = Hour;
    brain.Next(ctx);
    brain.Fed(ctx.ticks, false);
    ctx.ticks += 4000;
    CHECK(brain.Next(ctx).action == Action::Groom);
    brain.Fed(ctx.ticks, true);
    brain.Pet(ctx.ticks); // Feeding has priority over a simultaneous click.
    CHECK(brain.Next(ctx).action == Action::Groom);
    brain.Pet(ctx.ticks);
    const auto response = brain.Next(ctx);
    CHECK(response.action == Action::Watch || response.action == Action::Groom);
    ctx.roamingPaused = true; ctx.cursorNear = true;
    for (int i = 0; i < 3000; ++i) {
        const auto plan = brain.Next(ctx);
        CHECK(Stationary(plan.action));
        CHECK(plan.speed == 0.0);
        ctx.ticks += plan.durationMs;
    }

    // Pausing a stalking sequence suppresses its pending leap.
    Brain stalking(Birthday, 91);
    ctx = {}; ctx.cursorNear = true;
    bool found = false;
    for (int i = 0; i < 500; ++i) {
        const auto plan = stalking.Next(ctx);
        ctx.ticks += plan.durationMs;
        if (plan.action == Action::Stalk) { found = true; break; }
    }
    CHECK(found);
    ctx.roamingPaused = true;
    CHECK(stalking.Next(ctx).action == Action::Watch);
}

struct Sample { std::uint64_t sleep = 0, movement = 0, total = 0; double speed = 0.0; unsigned walks = 0; };
Sample SampleDay(int age, int hour) {
    Sample sample;
    for (unsigned seed = 1; seed <= 25; ++seed) {
        Brain brain(Birthday, seed);
        Context ctx; ctx.ageYears = age; ctx.localHour = hour;
        while (ctx.ticks < 12 * Hour) {
            const auto p = brain.Next(ctx);
            if (p.action == Action::Sleep) sample.sleep += p.durationMs;
            if (p.action == Action::Walk || p.action == Action::Zoomies || p.action == Action::Pounce) sample.movement += p.durationMs;
            if (p.action == Action::Walk) { sample.speed += p.speed; ++sample.walks; }
            sample.total += p.durationMs; ctx.ticks += p.durationMs;
        }
    }
    return sample;
}
void AgeAndCircadianVariation() {
    const auto kitten = SampleDay(0, 12), senior = SampleDay(14, 12), dusk = SampleDay(0, 19);
    CHECK(kitten.walks > 0 && senior.walks > 0);
    CHECK(senior.speed / senior.walks < kitten.speed / kitten.walks * 0.7);
    CHECK(senior.sleep * 1.0 / senior.total > kitten.sleep * 1.0 / kitten.total);
    CHECK(dusk.movement * 1.0 / dusk.total > kitten.movement * 1.0 / kitten.total);
    CHECK(dusk.sleep * 1.0 / dusk.total < kitten.sleep * 1.0 / kitten.total);
}

void TickRollbackAndInvalidInputs() {
    Brain brain(Birthday, 4);
    Context ctx; ctx.ticks = 100 * Hour;
    brain.MarkPunch(ctx.ticks);
    ctx.ticks = 100; // Rebase remaining cooldown, never wrap it into the past.
    const auto start = ctx.ticks;
    while (ctx.ticks < start + Brain::PunchMinGapMs) {
        const auto p = brain.Next(ctx);
        CHECK(p.action != Action::Punch);
        ctx.ticks += p.durationMs;
    }
    ctx.hunger = std::numeric_limits<double>::quiet_NaN();
    ctx.affection = std::numeric_limits<double>::infinity();
    ctx.ageYears = -20; ctx.localHour = -49;
    for (int i = 0; i < 20; ++i) {
        const auto p = brain.Next(ctx);
        CHECK(std::isfinite(p.speed) && p.durationMs > 0);
        ctx.ticks += p.durationMs;
    }
}
} // namespace

int main() {
    const std::vector<std::pair<std::string, std::function<void()>>> groups{
        {"stable personality and deterministic plans", PersonalityAndRepeatability},
        {"calm rhythm and coherent action sequences", CalmRhythmAndSequences},
        {"punch and surprise cooldowns at high uptime", CooldownsAndHighUptime},
        {"independent jump timing, cooldown and recovery", IndependentJumpAndRecovery},
        {"gentle gestures, independent cadence and pause", GentleGesturesAndPause},
        {"care responses and paused roaming", CareAndPause},
        {"age and dawn/dusk variation", AgeAndCircadianVariation},
        {"tick rollback and invalid-input bounds", TickRollbackAndInvalidInputs}
    };
    try {
        for (const auto& group : groups) { group.second(); std::cout << "PASS " << group.first << '\n'; }
        std::cout << groups.size() << " groups; " << checks << " checks passed\n";
    } catch (const std::exception& error) { std::cerr << error.what() << '\n'; return 1; }
}
