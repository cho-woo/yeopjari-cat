#include "../src/cat_preferences.hpp"

#include <cwchar>
#include <iostream>
#include <stdexcept>
#include <vector>

namespace {
int checks = 0;
#define CHECK(condition) do { ++checks; if (!(condition)) throw std::runtime_error( \
    std::string(__FILE__) + ":" + std::to_string(__LINE__) + " failed: " #condition); } while (false)

std::string Signed(const std::string& body, const std::string& ending = "\n") {
    std::ostringstream out;
    out << body << "checksum=" << std::hex << std::setw(16) << std::setfill('0')
        << cat::Checksum(body) << ending;
    return out.str();
}

void RejectWithoutMutation(const std::string& text) {
    for (const auto character : {cat::Character::Cream, cat::Character::SilverTabby}) {
        cat::Preferences destination{character};
        std::string error;
        CHECK(!cat::ParsePreferences(text, destination, error));
        CHECK(!error.empty());
        CHECK(destination.character == character);
    }
}

void RoundTripAndNames() {
    CHECK(cat::Preferences{}.character == cat::Character::Cream);
    CHECK(std::wcscmp(cat::CharacterName(cat::Character::Cream), L"크림 치즈냥") == 0);
    CHECK(std::wcscmp(cat::CharacterName(cat::Character::SilverTabby), L"실버 태비냥") == 0);
    for (const auto character : {cat::Character::Cream, cat::Character::SilverTabby}) {
        CHECK(cat::IsValid(character));
        const cat::Preferences original{character};
        const auto text = cat::SerializePreferences(original);
        CHECK(text.rfind("schema=1\ncharacter=", 0) == 0);
        CHECK(text.back() == '\n');
        CHECK(text.find('\r') == std::string::npos);
        cat::Preferences restored;
        std::string error = "previous error";
        CHECK(cat::ParsePreferences(text, restored, error));
        CHECK(error.empty());
        CHECK(restored.character == original.character);
        CHECK(cat::SerializePreferences(restored) == text);
        CHECK(cat::ParsePreferences(text, restored));
    }
    const auto invalid = static_cast<cat::Character>(7);
    CHECK(!cat::IsValid(invalid));
    CHECK(cat::SerializePreferences({invalid}).empty());
}

void InvalidContentAndTruncation() {
    const auto valid = cat::SerializePreferences({cat::Character::SilverTabby});
    RejectWithoutMutation("");
    RejectWithoutMutation("broken");
    RejectWithoutMutation(std::string(2049, 'x'));
    for (const std::string body : {
        "schema=2\ncharacter=cream\n", "schema=1\ncharacter=orange\n",
        "schema=1\ncharacter=1\n", "schema=1\ncharacter=cream\nextra=1\n",
        "schema=1\ncharacter=cream\ncharacter=silver_tabby\n",
        "character=cream\nschema=1\n", "schema=1\ncharacter=cream", "schema=1\n",
        "schema=1\ncharacter=cream \n", "schema=1\r\ncharacter=cream\n"})
        RejectWithoutMutation(Signed(body));

    // Missing only the optional final newline is valid; all partial records fail.
    for (std::size_t cut = 0; cut + 1 < valid.size(); ++cut)
        RejectWithoutMutation(valid.substr(0, cut));
    cat::Preferences destination;
    CHECK(cat::ParsePreferences(valid.substr(0, valid.size() - 1), destination));
    CHECK(destination.character == cat::Character::SilverTabby);

    std::string corrupt = valid;
    corrupt[corrupt.find("silver_tabby")] = 'S';
    RejectWithoutMutation(corrupt);
    corrupt = valid;
    corrupt[corrupt.size() - 2] = corrupt[corrupt.size() - 2] == '0' ? '1' : '0';
    RejectWithoutMutation(corrupt);
    RejectWithoutMutation(valid + "\n");
    RejectWithoutMutation(valid + "trailing data");
    RejectWithoutMutation("prefix\n" + valid);
}

void ExactBytesAndWindowsNewlines() {
    cat::Preferences destination;
    for (const std::string character : {"cream", "silver_tabby"}) {
        const auto body = "schema=1\r\ncharacter=" + character + "\r\n";
        const auto crlf = Signed(body, "\r\n");
        CHECK(cat::ParsePreferences(crlf, destination));
        CHECK(destination.character == (character == "cream" ? cat::Character::Cream : cat::Character::SilverTabby));
    }
    const auto canonical = cat::SerializePreferences({cat::Character::Cream});
    std::string changedNewlines;
    for (char ch : canonical) { if (ch == '\n') changedNewlines += '\r'; changedNewlines += ch; }
    RejectWithoutMutation(changedNewlines); // Its old checksum describes different bytes.
}

void ExistingPetIsIndependent() {
    auto pet = cat::NewPet(cat::ToUnix({2026, 10, 31, 3, 14, 15}));
    cat::Feed(pet, pet.bornUtc + 86400, false);
    cat::Feed(pet, pet.bornUtc + 172800, true);
    pet.roamingPaused = true;
    pet.position = 0.123456;
    const auto saved = cat::Serialize(pet);
    cat::Preferences prefs;
    for (int i = 0; i < 20; ++i) {
        prefs.character = i % 2 ? cat::Character::Cream : cat::Character::SilverTabby;
        CHECK(cat::ParsePreferences(cat::SerializePreferences(prefs), prefs));
        CHECK(cat::Serialize(pet) == saved);
    }
    RejectWithoutMutation(saved); // A growth record cannot be mistaken for preferences.
    cat::PetState loaded;
    std::string error;
    CHECK(cat::Parse(saved, loaded, error));
    CHECK(cat::Serialize(loaded) == saved);
    CHECK(loaded.bornUtc == pet.bornUtc);
    CHECK(loaded.feedCount == 1 && loaded.snackCount == 1);
}
} // namespace

int main() {
    try {
        RoundTripAndNames();
        InvalidContentAndTruncation();
        ExactBytesAndWindowsNewlines();
        ExistingPetIsIndependent();
        std::cout << "PASS: 4 preference groups; " << checks << " checks\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
