#pragma once

#include "pet_state.hpp"
#include <iomanip>
#include <locale>
#include <sstream>
#include <string>

namespace cat {

// Appearance is intentionally independent of the pet's birthday and care record.
enum class Character { Cream = 0, SilverTabby = 1 };
struct Preferences { Character character = Character::Cream; };

inline bool IsValid(Character character) noexcept {
    return character == Character::Cream || character == Character::SilverTabby;
}

inline const wchar_t* CharacterName(Character character) noexcept {
    switch (character) {
        case Character::Cream: return L"크림 치즈냥";
        case Character::SilverTabby: return L"실버 태비냥";
        default: return L"알 수 없는 고양이";
    }
}

inline std::string SerializePreferences(const Preferences& preferences) {
    if (!IsValid(preferences.character)) return {};
    const std::string body = std::string("schema=1\ncharacter=") +
        (preferences.character == Character::Cream ? "cream\n" : "silver_tabby\n");
    std::ostringstream out;
    out.imbue(std::locale::classic());
    out << body << "checksum=" << std::hex << std::setw(16) << std::setfill('0')
        << Checksum(body) << '\n';
    return out.str();
}

inline bool ParsePreferences(const std::string& text, Preferences& destination, std::string& error) {
    auto fail = [&](const char* why) { error = why; return false; };
    if (text.empty() || text.size() > 2048) return fail("Empty or oversized preferences");
    const auto checksumAt = text.rfind("checksum=");
    if (checksumAt == std::string::npos || checksumAt == 0 || text[checksumAt - 1] != '\n')
        return fail("Missing preference checksum");
    const std::string body = text.substr(0, checksumAt);
    std::string hash = text.substr(checksumAt + 9);
    if (!hash.empty() && hash.back() == '\n') {
        hash.pop_back();
        if (!hash.empty() && hash.back() == '\r') hash.pop_back();
    }
    if (hash.size() != 16 || hash.find_first_not_of("0123456789abcdefABCDEF") != std::string::npos)
        return fail("Malformed preference checksum");
    std::uint64_t expected = 0;
    std::istringstream input(hash);
    input.imbue(std::locale::classic());
    input >> std::hex >> expected;
    // Never normalize before verifying: edits to the actual stored bytes are detected.
    if (!input || expected != Checksum(body)) return fail("Preference checksum mismatch");

    Preferences parsed;
    if (body == "schema=1\ncharacter=cream\n" || body == "schema=1\r\ncharacter=cream\r\n")
        parsed.character = Character::Cream;
    else if (body == "schema=1\ncharacter=silver_tabby\n" || body == "schema=1\r\ncharacter=silver_tabby\r\n")
        parsed.character = Character::SilverTabby;
    else return fail("Unsupported or malformed preferences");

    destination = parsed;
    error.clear();
    return true;
}

inline bool ParsePreferences(const std::string& text, Preferences& destination) {
    std::string error;
    return ParsePreferences(text, destination, error);
}

} // namespace cat
