#include "../src/cat_behavior.hpp"

#include <array>
#include <cwchar>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {
using cat::behavior::Action;
using cat::behavior::Brain;
using cat::behavior::Context;
int checks = 0;
#define CHECK(condition) do { ++checks; if (!(condition)) throw std::runtime_error( \
    std::string(__FILE__) + ":" + std::to_string(__LINE__) + " failed: " #condition); } while (false)
constexpr std::int64_t Birthday = 1793416455;
constexpr std::uint64_t Hour = 60ULL * 60ULL * 1000ULL;

bool Travels(Action a) {
    return a == Action::Walk || a == Action::Stalk || a == Action::Pounce || a == Action::Zoomies || a == Action::Jump;
}

void StablePersonalityAndName() {
    Brain a(Birthday, 1), b(Birthday, 999), c(Birthday + 1, 1);
    const auto pa=a.GetPersonality(), pb=b.GetPersonality(), pc=c.GetPersonality();
    CHECK(pa.curiosity==pb.curiosity && pa.energy==pb.energy && pa.sociability==pb.sociability && pa.mischief==pb.mischief);
    CHECK(a.GetArchetype()==b.GetArchetype());
    CHECK(std::wcslen(cat::behavior::ArchetypeName(a.GetArchetype())) >= 2);
    CHECK(pa.curiosity!=pc.curiosity || pa.energy!=pc.energy || pa.sociability!=pc.sociability || pa.mischief!=pc.mischief);
    for(double v:{pa.curiosity,pa.energy,pa.sociability,pa.mischief}) CHECK(v>=.18 && v<.82);
}

void DeterministicDailyOrder() {
    Brain a(Birthday,77), b(Birthday,77);
    Context ctx; ctx.cursorNear=true;
    for(int i=0;i<1200;++i) {
        auto x=a.Next(ctx), y=b.Next(ctx);
        CHECK(x.action==y.action && x.durationMs==y.durationMs && x.speed==y.speed);
        CHECK(x.durationMs>=1000 && x.durationMs<=120000);
        CHECK(x.speed>=0 && x.speed<=250);
        ctx.ticks += x.durationMs;
        ctx.localHour = static_cast<int>((ctx.ticks/Hour+8)%24);
    }
}

void PausedCatStaysPut() {
    Brain brain(Birthday,31); Context ctx; ctx.roamingPaused=true; ctx.cursorNear=true;
    for(int i=0;i<4000;++i) {
        auto p=brain.Next(ctx);
        CHECK(!Travels(p.action));
        CHECK(p.speed==0.0);
        ctx.ticks += p.durationMs;
    }
}

void NewActionsAndSequencesAppear() {
    std::array<unsigned, static_cast<unsigned>(Action::Sneeze)+1> seen{};
    bool kneadSequence=false, bellySequence=false, zoomSequence=false;
    for(unsigned seed=1; seed<=24; ++seed) {
        Brain brain(Birthday,seed); Context ctx; ctx.cursorNear=true;
        Action previous=Action::Idle;
        for(int i=0;i<12000;++i) {
            auto p=brain.Next(ctx);
            ++seen[static_cast<unsigned>(p.action)];
            if(previous==Action::Knead && p.action==Action::Loaf) kneadSequence=true;
            if(previous==Action::BellyRoll && p.action==Action::Groom) bellySequence=true;
            if(previous==Action::Zoomies && (p.action==Action::Jump || p.action==Action::Watch)) zoomSequence=true;
            previous=p.action;
            ctx.ticks += p.durationMs;
            ctx.localHour=static_cast<int>((ctx.ticks/Hour+6)%24);
        }
    }
    for(auto a:{Action::Loaf,Action::Knead,Action::Peek,Action::Scratch,Action::Sneeze,Action::BellyRoll,Action::TailRaise,Action::Jump})
        CHECK(seen[static_cast<unsigned>(a)]>0);
    CHECK(kneadSequence); CHECK(bellySequence); CHECK(zoomSequence);
}

void FeedingAndPettingCreateCalmFollowups() {
    Brain brain(Birthday,13); Context ctx; ctx.ticks=100000;
    brain.Fed(ctx.ticks,false);
    auto groom=brain.Next(ctx); CHECK(groom.action==Action::Groom);
    ctx.ticks += groom.durationMs;
    brain.Pet(ctx.ticks);
    auto reply=brain.Next(ctx);
    CHECK(reply.action==Action::Watch || reply.action==Action::Groom || reply.action==Action::Knead);
}
}

int main(){
    try{
        StablePersonalityAndName(); DeterministicDailyOrder(); PausedCatStaysPut(); NewActionsAndSequencesAppear(); FeedingAndPettingCreateCalmFollowups();
        std::cout<<"PASS: personality, new actions and sequences; "<<checks<<" checks\n"; return 0;
    } catch(const std::exception& e){ std::cerr<<e.what()<<'\n'; return 1; }
}
